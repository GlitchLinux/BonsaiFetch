#!/bin/bash
# 01-hostname.sh

module_hostname() {
    echo " $(hostname)"
}

# Execute if run directly
module_hostname
