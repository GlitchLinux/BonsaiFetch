#!/bin/bash
# 99-separator.sh

module_separator() {
    echo "────────────────────"
}

# Execute if run directly
module_separator
