#!/bin/bash
# 03-kernel.sh

module_kernel() {
    echo "  $(uname -r)"
}

# Execute if run directly
module_kernel
