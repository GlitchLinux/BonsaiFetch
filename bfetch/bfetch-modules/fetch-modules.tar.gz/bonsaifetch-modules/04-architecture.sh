#!/bin/bash
# 04-architecture.sh

module_architecture() {
    echo " $(uname -m)"
}

# Execute if run directly
module_architecture
