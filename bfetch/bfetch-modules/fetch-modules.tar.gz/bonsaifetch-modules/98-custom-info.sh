#!/bin/bash
# 98-custom-info.sh

module_custom() {
    # Add your own custom information here
    echo "󰠮 Custom Info"
}
module_custom() {
    # Your logic here
    echo "󰠮 Your output"
}

# Execute if run directly
module_custom
